import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk
import os
import subprocess
from shutil import copyfile

this_file_path = os.path.dirname(os.path.realpath(__file__)) + os.sep

# --- functions ---

def on_click(event=None):
    # `command=` calls function without argument
    # `bind` calls function with one argument
    id = event.widget.id
    if clicked[int(id) - 1]:
        clicked[int(id) - 1] = False
        event.widget.configure(image=photos[int(id) - 1])
    else:
        clicked[int(id) - 1] = True
        event.widget.configure(image=photos_overlayed[int(id) - 1])

class Btn(tk.Button):
    """Create custom button with an extra property: id"""
    def define_id(self, btn_id):
        self.id = btn_id

def submit(event=None):
    print('submit clicked')
    """Stylize images inside images/content_images and execute apply.bash"""
    # Disable button
    btnSubmit.configure(state='disabled')
    btnSubmit.config(text='Processing...')
    root.update()

    # Copy images to right folders
    for i in range(len(clicked)):
        if clicked[i]:
            src = 'images/style_images/textures/texture_' + str(i + 1) + '.jpg'
            copyfile(src, src.replace('/textures', ''))
    
    # Run image stylization
    os.system('bash ' + this_file_path + 'apply.sh')
    print('Stylizing done! You can find the results on "output" folder')

    # Delete copied files to go back to normal state
    for i in range(len(clicked)):
        if clicked[i]:
            f_name = 'images/style_images/texture_' + str(i + 1) + '.jpg'
            os.remove(f_name)

    # Enable button
    btnSubmit.configure(state='normal')
    btnSubmit.config(text='Submit')

    # Open folder with results
    subprocess.Popen(["xdg-open", this_file_path + 'output'])


# --- main ---

# init    
root = tk.Tk()

images = []
photos = []
images_overlayed = []
photos_overlayed = []
c = 0
clicked = [False for i in range(16)]

for i in range(4):
    for j in range(4):
        c += 1
        # load image
        images.append(Image.open("images/style_images/textures/texture_" + str(c) + ".jpg"))
        photos.append(ImageTk.PhotoImage(images[-1]))

        images_overlayed.append(Image.open("images/style_images/textures/texture_" + str(c) + "_overlayed.jpg"))
        photos_overlayed.append(ImageTk.PhotoImage(images_overlayed[-1]))

        # button with image binded to the same function
        b = Btn(root, image=photos[-1])
        b.define_id(str(c))
        b.bind('<Button-1>', on_click)
        b.grid(row=i, column=j)

btnSubmit = tk.Button(root, text='Submit', height=7, width=14)
btnSubmit.bind('<Button-1>', submit)
btnSubmit.grid(row=4, column=0, columnspan=4, pady=20)

# Select one or more images (jpg only)
answer = filedialog.askopenfilenames(parent=root,
                                     initialdir=os.getcwd(),
                                     title="Please select one or more files:",
                                     filetypes=[('jpg images', '.jpg')])


# Put the images in the right folder to be processed
for im_path in answer:
    im_name = im_path.split(os.sep)[-1]
    copyfile(im_path, this_file_path + 'images/content_images/' + im_name)

# "start the engine"
root.mainloop()
